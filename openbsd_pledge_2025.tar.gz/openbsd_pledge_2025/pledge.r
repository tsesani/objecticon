#passthru #include <unistd.h>
#passthru #include <err.h>

function _pledge(promises, execpromises)
   if !cnv:C_string(promises) then
      runerr(103, promises)
   if !cnv:C_string(execpromises) then
      runerr(103, execpromises)
   body {
      int rc;
      rc = pledge(promises, execpromises);
      return C_integer rc;
   }
end
