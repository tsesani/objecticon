/*
 * Copyright (c) 2025 Jason Martin <jason.martin@centurylink.net>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#passthru #include "mpdecimal.h"

mpd_context_t ctx;
int notation = 0;


function Decimal_initialize(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        if (x < 0 || x > MPD_MAX_PREC)
            Irunerr(205, x);
        mpd_init(&ctx, x);
        return C_integer 0;
    }
end

function Decimal_basiccontext(self)
    body {
        mpd_basiccontext(&ctx);
        return C_integer 0;
    }
end

function Decimal_defaultcontext(self)
    body {
        mpd_defaultcontext(&ctx);
        return C_integer 0;
    }
end

function Decimal_ieee_context(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        mpd_ieee_context(&ctx, x);
        return C_integer 0;
    }
end

function Decimal_maxcontext(self)
    body {
        mpd_maxcontext(&ctx);
        return C_integer 0;
    }
end

function Decimal_getmaxemax(self)
    body {
        return C_integer MPD_MAX_EMAX;
    }
end

function Decimal_getmaxprec(self)
    body {
        return C_integer MPD_MAX_PREC;
    }
end

function Decimal_getminemin(self)
    body {
        return C_integer MPD_MIN_EMIN;
    }
end

function Decimal_outform(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        if (x < 0 || x > 1)
            Irunerr(205, x);
        notation = x;
        return C_integer 0;
    }
end

function Decimal_compare_total_mag(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_compare_total_mag(q, a, b);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_compare_total(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_compare_total(q, a, b);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_getclamp(self)
    body {
        return C_integer mpd_getclamp(&ctx);
    }
end

function Decimal_getcr(self)
    body {
        return C_integer mpd_getcr(&ctx);
    }
end

function Decimal_getemax(self)
    body {
        return C_integer mpd_getemax(&ctx);
    }
end

function Decimal_getemin(self)
    body {
        return C_integer mpd_getemin(&ctx);
    }
end

function Decimal_getprec(self)
    body {
        return C_integer mpd_getprec(&ctx);
    }
end

function Decimal_getround(self)
    body {
        return C_integer mpd_getround(&ctx);
    }
end

function Decimal_getstatus(self)
    body {
        return C_integer mpd_getstatus(&ctx);
    }
end

function Decimal_gettraps(self)
    body {
        return C_integer mpd_gettraps(&ctx);
    }
end

function Decimal_abs(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qabs(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_add(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qadd(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_and(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qand(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_ceil(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qceil(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_cmp(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        mpd_t *a, *b;
        uint32_t status = 0;
        int i;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        i = mpd_qcmp(a, b, &status);
        mpd_del(a);
        mpd_del(b);
        return C_integer i;
    }
end

function Decimal_compare(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qcompare(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_compare_signal(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qcompare_signal(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_copy(self, x)
    body {
        tended char *c_x;
        char *rstring;
        int i;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        i = mpd_qcopy(q, a, &status);
        if (i == 0) {
            mpd_del(a);
            mpd_del(q);
            LitWhy("mpd_qcopy failed");
            fail;
        }
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_copy_abs(self, x)
    body {
        tended char *c_x;
        char *rstring;
        int i;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        i = mpd_qcopy_abs(q, a, &status);
        if (i == 0) {
            mpd_del(a);
            mpd_del(q);
            LitWhy("mpd_qcopy_abs failed");
            fail;
        }
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_copy_negate(self, x)
    body {
        tended char *c_x;
        char *rstring;
        int i;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        i = mpd_qcopy_negate(q, a, &status);
        if (i == 0) {
            mpd_del(a);
            mpd_del(q);
            LitWhy("mpd_qcopy_negate failed");
            fail;
        }
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_copy_sign(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        int i;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        i = mpd_qcopy_sign(q, a, b, &status);
        if (i == 0) {
            mpd_del(a);
            mpd_del(b);
            mpd_del(q);
            LitWhy("mpd_qcopy_sign failed");
            fail;
        }
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_div(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qdiv(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_divint(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qdivint(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_divmod(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *joined, *qstring, *rstring;
        mpd_t *a, *b, *q, *r;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        r = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qdivmod(q, r, a, b, &ctx, &status);
        if (notation > 0) {
            qstring = mpd_to_eng(q, 1);
            rstring = mpd_to_eng(r, 1);
        } else {
            qstring = mpd_to_sci(q, 1);
            rstring = mpd_to_sci(r, 1);
        }
        joined = malloc(strlen(qstring)+strlen(rstring)+4);
        sprintf(joined, "%s %s", qstring, rstring);
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        mpd_del(r);
        /*mpd_free(joined);*/
        return C_string joined;
    }
end

function Decimal_exp(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qexp(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_floor(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qfloor(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_fma(self, x, y, z)
    body {
        tended char *c_x;
        tended char *c_y;
        tended char *c_z;
        char *rstring;
        mpd_t *a, *b, *c, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        if (!cnv:C_string(z, c_z))
            runerr(103, z);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        c = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_set_string(c, c_z, &ctx);
        mpd_qfma(q, a, b, c, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(c);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_invert(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qinvert(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_invroot(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qinvroot(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_ln(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qln(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_ln10(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        char *rstring;
        mpd_t *q;
        uint32_t status = 0;
        ctx.traps = 0;
        q = mpd_new(&ctx);
        mpd_qln10(q, x, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_log10(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qlog10(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_logb(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qlogb(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_max(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qmax(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_max_mag(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qmax_mag(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_min(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qmin(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_min_mag(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qmin_mag(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_minus(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qminus(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_mul(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qmul(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_next_minus(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qnext_minus(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_next_plus(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qnext_plus(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_next_toward(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qnext_toward(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_or(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qor(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_plus(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qplus(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_pow(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qpow(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_powmod(self, x, y, z)
    body {
        tended char *c_x;
        tended char *c_y;
        tended char *c_z;
        char *rstring;
        mpd_t *a, *b, *c, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        if (!cnv:C_string(z, c_z))
            runerr(103, z);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        c = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_set_string(c, c_y, &ctx);
        mpd_qpowmod(q, a, b, c, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(c);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_quantize(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qquantize(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_reduce(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qreduce(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_rem(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qrem(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_rem_near(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qrem_near(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_rescale(self, x, y)
    if !cnv:C_integer(y) then
        runerr(101, y);
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qrescale(q, a, y, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_resize(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        char *rstring;
        int i;
        mpd_t *q;
        uint32_t status = 0;
        ctx.traps = 0;
        q = mpd_new(&ctx);
        i = mpd_qresize(q, x, &status);
        if (i == 0) {
            mpd_del(q);
            LitWhy("mpd_qresize failed");
            fail;
        }
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_rotate(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qrotate(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_round_to_int(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qround_to_int(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_round_to_intx(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qround_to_intx(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_scaleb(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qscaleb(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_setclamp(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        if (x < 0 || x > 1)
            Irunerr(205, x);
        return C_integer mpd_qsetclamp(&ctx, x);
    }
end

function Decimal_setcr(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        if (x < 0 || x > 1)
            Irunerr(205, x);
        return C_integer mpd_qsetcr(&ctx, x);
    }
end

function Decimal_setemax(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        if (x > MPD_MAX_EMAX)
            Irunerr(205, x);
        return C_integer mpd_qsetemax(&ctx, x);
    }
end

function Decimal_setemin(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        if (x < MPD_MIN_EMIN)
            Irunerr(205, x);
        return C_integer mpd_qsetemin(&ctx, x);
    }
end

function Decimal_setprec(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        if (x <= 0 || x > MPD_MAX_PREC)
            Irunerr(205, x);
        return C_integer mpd_qsetprec(&ctx, x);
    }
end

function Decimal_setround(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        if (x < 0 || x > 8)
            Irunerr(205, x);
        return C_integer mpd_qsetround(&ctx, x);
    }
end

function Decimal_setstatus(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        if (x < 0 || x > MPD_Max_status)
            Irunerr(205, x);
        return C_integer mpd_qsetstatus(&ctx, x);
    }
end

function Decimal_settraps(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        if (x < 0 || x > MPD_Max_status)
            Irunerr(205, x);
        return C_integer mpd_qsettraps(&ctx, x);
    }
end

function Decimal_shift(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qshift(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_shiftl(self, x, y)
    if !cnv:C_integer(y) then
        runerr(101, y);
    body {
        tended char *c_x;
        char *rstring;
        int i;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        i = mpd_qshiftl(q, a, y, &status);
        if (i == 0) {
            mpd_del(a);
            mpd_del(q);
            LitWhy("mpd_qshiftl failed");
            fail;
        }
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_shiftr(self, x, y)
    if !cnv:C_integer(y) then
        runerr(101, y);
    body {
        tended char *c_x;
        char *rstring;
        int i;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        i = mpd_qshiftr(q, a, y, &status);
        if (i == MPD_UINT_MAX) {
            mpd_del(a);
            mpd_del(q);
            LitWhy("mpd_qshiftr failed");
            fail;
        }
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_sub(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qsub(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_trunc(self, x)
    body {
        tended char *c_x;
        char *rstring;
        mpd_t *a, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        a = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_qtrunc(q, a, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_xor(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        char *rstring;
        mpd_t *a, *b, *q;
        uint32_t status = 0;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        q = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        mpd_qxor(q, a, b, &ctx, &status);
        if (notation > 0) {
            rstring = mpd_to_eng(q, 1);
        } else {
            rstring = mpd_to_sci(q, 1);
        }
        mpd_del(a);
        mpd_del(b);
        mpd_del(q);
        return C_string rstring;
    }
end

function Decimal_same_quantum(self, x, y)
    body {
        tended char *c_x;
        tended char *c_y;
        int i;
        mpd_t *a, *b;
        ctx.traps = 0;
        if (!cnv:C_string(x, c_x))
            runerr(103, x);
        if (!cnv:C_string(y, c_y))
            runerr(103, y);
        a = mpd_new(&ctx);
        b = mpd_new(&ctx);
        mpd_set_string(a, c_x, &ctx);
        mpd_set_string(b, c_y, &ctx);
        i = mpd_same_quantum(a, b);
        mpd_del(a);
        mpd_del(b);
        return C_integer i;
    }
end

function Decimal_setminalloc(self, x)
    if !cnv:C_integer(x) then
        runerr(101, x);
    body {
        if (x < 2 || x > 64)
            Irunerr(205, x);
        mpd_setminalloc(x);
        return C_integer 0;
    }
end
