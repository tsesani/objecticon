typedef int mpd_context_t, mpd_t, mpd_spec_t, mpd_ssize_t, mpd_uint_t, uint32_t;
