# Remove version from tests
grep -v "version: " $1 > /tmp/1.decTest
# Remove dectest from tests
grep -v "dectest: " /tmp/1.decTest > /tmp/2.decTest
# Clean /tmp
rm /tmp/1.decTest
# Remove comments from tests
grep -v "^--"  /tmp/2.decTest > /tmp/3.decTest
# Clean /tmp
rm /tmp/2.decTest
# Remove more comments from tests
grep -v "^\s"  /tmp/3.decTest > /tmp/4.decTest
# Clean /tmp
rm /tmp/3.decTest
# Standardize case of words -- YOU MAY NEED TO REPLACE GSED WITH SED.
gsed -i 's/Clamp/clamp/g' /tmp/4.decTest
gsed -i 's/Half_even/half_even/g' /tmp/4.decTest
gsed -i 's/MaxExponent/maxexponent/g' /tmp/4.decTest
gsed -i 's/Maxexponent/maxexponent/g' /tmp/4.decTest
gsed -i 's/MinExponent/minexponent/g' /tmp/4.decTest
gsed -i 's/Minexponent/minexponent/g' /tmp/4.decTest
gsed -i 's/Precision/precision/g' /tmp/4.decTest
gsed -i 's/Rounding/rounding/g' /tmp/4.decTest
gsed -i 's/Up/up/g' /tmp/4.decTest
gsed -i 's/maxExponent/maxexponent/g' /tmp/4.decTest
gsed -i 's/minExponent/minexponent/g' /tmp/4.decTest
gsed -i 's/remainderNear/remaindernear/g' /tmp/4.decTest
gsed -i 's/toeng/toEng/g' /tmp/4.decTest
gsed -i 's/tosci/toSci/g' /tmp/4.decTest

# Remove tests mpdecimal skips and those not implemented by me.
# Remove some that taxed my system.
# Remove all with status Invalid_operation

echo "absx900
addx9990
addx9991
clam090
clam091
clam092
clam093
clam094
clam095
clam096
clam097
clam098
clam099
clam189
clam190
clam191
clam192
clam193
clam194
clam195
clam196
clam197
clam198
clam199
comx990
comx991
cotx9990
cotx9991
ctmx9990
ctmx9991
ddabs900
ddadd9990
ddadd9991
ddcom9990
ddcom9991
ddcot9990
ddcot9991
ddctm9990
ddctm9991
dddiv9998
dddiv9999
dddvi900
dddvi901
ddfma2990
ddfma2991
ddfma39990
ddfma39991
ddlogb900
ddmax900
ddmax901
ddmxg900
ddmxg901
ddmin900
ddmin901
ddmng900
ddmng901
ddmul9990
ddmul9991
ddnextm900
ddnextm900
ddnextp900
ddnextp900
ddnextt900
ddnextt901
ddqua998
ddqua999
ddred900
ddrem1000
ddrem1001
ddrmn1000
ddrmn1001
ddsub9990
ddsub9991
ddintx074
ddintx094
divx9998
divx9999
dvix900
dvix901
dqabs900
dqadd9990
dqadd9991
dqcom990
dqcom991
dqcot9990
dqcot9991
dqctm9990
dqctm9991
dqdiv9998
dqdiv9999
dqdvi900
dqdvi901
dqfma2990
dqfma2991
dqadd39990
dqadd39991
dqlogb900
dqmax900
dqmax901
dqmxg900
dqmxg901
dqmin900
dqmin901
dqmng900
dqmng901
dqmul9990
dqmul9991
dqnextm900
dqnextp900
dqnextt900
dqnextt901
dqqua998
dqqua999
dqred900
dqrem1000
dqrem1001
dqrmn1000
dqrmn1001
dqsub9990
dqsub9991
dqintx074
dqintx094
expx900
fmax2990
fmax2991
fmax39990
fmax39991
lnx900
logx900
logbx900
maxx900
maxx901
mxgx900
mxgx901
mnm900
mnm901
mng900
mng901
minx900
mulx990
mulx991
nextm900
nextp900
nextt900
nextt901
plu900
powx900
powx901
pwsx900
quax1022
quax1023
quax1024
quax1025
quax1026
quax1027
quax1028
quax1029
quax0a2
quax0a3
quax998
quax999
redx900
remx1000
remx1001
rmnx900
rmnx901
sqtx9900
subx9990
subx9991
expx901
expx902
expx903
expx905
lnx901
lnx902
lnx903
lnx905
logx901
logx902
logx903
logx905
powx1183
powx1184
powx4001
powx4002
powx4003
powx4005
powx4008
powx4010
powx4012
powx4014
scbx164
scbx165
scbx166
sqtx9045
powx4302
powx4303
powx4303
powx4342
powx4343
pwsx805
pwmx325
pwmx326
ddbas911
ddbas912
ddbas913
ddbas914
ddbas915
ddbas916
ddbas917
ddbas918
ddbas919
ddbas920
ddbas921
ddbas922
ddbas923
ddbas924
ddbas925
ddbas926
ddbas927
ddbas928
ddbas929
ddbas1004
ddbas1005
ddbas1006
ddbas1007
ddbas1008
ddbas1009
ddbas1010
ddbas1011
ddbas1012
ddbas1041
ddbas1042
ddbas1043
apply
baseconv
canonical
class
format
get_i32
get_i64
get_ssize32
get_ssize64
get_u32
get_u64
get_uint32
get_uint32_abs
get_uint64
get_uint64_abs
squareroot
toEng
toSci
trim
Invalid_operation" > /tmp/skip_these.txt

# Remove my skipped test list.
grep -v -f /tmp/skip_these.txt /tmp/4.decTest > /tmp/5.decTest
# Clean /tmp
rm /tmp/4.decTest
rm /tmp/skip_these.txt
# Remove quotes from operands
gsed -e 's|["'\'']||g' /tmp/5.decTest > /tmp/6.decTest
# Clean /tmp
rm /tmp/5.decTest
# dos2unix
tr -d '\015' < /tmp/6.decTest > /tmp/7.decTest
# Clean /tmp
rm /tmp/6.decTest
# Remove empty lines
grep -v '^\s*$'  /tmp/7.decTest > /tmp/8.decTest
# Clean /tmp
rm /tmp/7.decTest
# Combine spaces into just one.
tr -s ' ' < /tmp/8.decTest > /tmp/9.decTest
# Clean /tmp
rm /tmp/8.decTest
# Remove all tests with operands that have pound sign
grep -v "#"  /tmp/9.decTest > /tmp/$1
# Clean /tmp
rm /tmp/9.decTest
# REMEMBER TO GRAB YOUR FILE FROM /tmp
